import java.util.*;

class bookingticket {
    private ArrayList<movie> film = new ArrayList<>();

    public void addMovie(movie m) {
        film.add(m);
        System.out.println("Movie is added and saved");
    }

    public void viewMovie() {
        if (film.isEmpty()) {
            System.out.println("No movies are available for viewing");
            return;
        }

        for (movie m : film) {
            System.out.println(
               "ID:"+ m.getId() + "\n " +
                "Movie Name:"+m.getName() + "\n" +
               "Show Time:" +m.getShow() + "\n" +
                "Seats Available:"+m.getSeat()
            );
        }
    }

    public movie searchMovie(int id) {
        for (movie m : film) {
            if (m.getId() == id) {
                return m;
            }
        }
        return null;
    }

    public void cancelMovie(int id) {
        movie m = searchMovie(id);
        if (m != null) {
            film.remove(m);
            System.out.println("Movie is removed");
        } else {
            System.out.println("Movie is not found");
        }
    }

    public int check(String name) {
        for (movie m : film) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m.getId();
            }
        }
        return -1;
    }
    public int checktime(String time) {
        for (movie m : film) {
            if (m.getShow().equalsIgnoreCase(time)) {
                return m.getId();
            }
        }
        return -1;
    }

    public int checkseats(int s) {
        for (movie m : film) {
            if (m.getSeat()>=s) {
                return m.getId();
            }
        }
        return -1;
    }


    public String booking(String mname, String time, int s) {
        return "Your ticket is being booked\n" +
               "Movie: " + mname + "\n" +
               "Show time: " + time + "\n" +
               "Seats: " + s;
    }

    public void countSeat() {
        int totalSeats = 0;
        for (movie m : film) {
            totalSeats += m.getSeat();
        }
        System.out.println("Total seats: " + totalSeats);
    }
}