class movie {
    private int id;
    private String name;
    private String show;
    private int seats;

    public movie(int id, String name, String show, int seats) {
        this.id = id;
        this.name = name;
        this.show = show;
        this.seats = seats;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setShow(String show) {
        this.show = show;
    }

    public void setSeat(int seats) {
        this.seats = seats;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getShow() {
        return show;
    }

    public int getSeat() {
        return seats;
    }

    public String display() {
        return "Movie :\n" + "id : " + id + "\n" + "name : " + name + "\n" + "show : " + show + "\n" + "seats = " + seats;
    }
}