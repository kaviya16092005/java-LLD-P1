import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        bookingticket bt = new bookingticket();

        while (true) {
            System.out.println("1. Add a new movie");
            System.out.println("2. View all available movie");
            System.out.println("3. Book a ticket for a movie");
            System.out.println("4. Cancel a booked ticket");
            System.out.println("5. Search for a movie");
            System.out.println("6. Display the count of available seats");
            System.out.println("7. Exit");
            System.out.print("Enter the choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1: {
                    System.out.print("Enter Movie Id: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Movie Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Show Time: ");
                    String show = sc.nextLine();

                    System.out.print("Enter number of available seats: ");
                    int seats = sc.nextInt();
                    sc.nextLine();

                    bt.addMovie(new movie(id, name, show, seats));
                    break;
                }

                case 2:
                    bt.viewMovie();
                    break;

                case 3: {
                    System.out.print("Enter Movie name: ");
                    String mname = sc.nextLine();

                    if (bt.check(mname) == -1) {
                        System.out.println("Movie is currently not available");
                        break;
                    }

                    System.out.print("Enter the show time: ");
                    String time = sc.nextLine();
                     if (bt.checktime(time) == -1) {
                        System.out.println("Movie show time is currently not available");
                        break;
                    }
                    System.out.print("Enter the no of seats: ");
                    int s = sc.nextInt();
                    sc.nextLine();

                    if (bt.checkseats(s) == -1) {
                        System.out.println("You entered more than available seats.");
                        break;
                    }

                    System.out.println(bt.booking(mname, time, s));
                    break;
                }

                case 4: {
                    System.out.print("Enter Id: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    bt.cancelMovie(id);
                    break;
                }

                case 5: {
                    System.out.print("Enter Movie Id: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    movie m = bt.searchMovie(id);
                    if (m != null)
                        System.out.println(m.display());
                    else
                        System.out.println("Movie not available");
                    break;
                }

                case 6:
                    bt.countSeat();
                    break;

                case 7:
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}